package com.compustore.users_service.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.security.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import java.util.List;

@Configuration
public class Configopenapi {
  @Bean
  public OpenAPI api() {
    final String scheme = "bearerAuth";
    return new OpenAPI()
      .info(new Info().title("Users API").description("Autenticación y JWT").version("v1"))
      .addSecurityItem(new SecurityRequirement().addList(scheme))
      .components(new Components().addSecuritySchemes(scheme,
        new SecurityScheme().name(scheme).type(SecurityScheme.Type.HTTP)
          .scheme("bearer").bearerFormat("JWT")));
  }
  
  @Bean
  public SecurityContext securityContext() {
    return SecurityContext.builder()
      .securityReferences(defaultAuth())
      .operationSelector(operation -> true)
      .build();
  }

  private List<SecurityReference> defaultAuth() {
    AuthorizationScope authorizationScope = new AuthorizationScope("global", "AccessEverything");
    return List.of(new SecurityReference("bearerAuth", new AuthorizationScope[] { authorizationScope }));
  }
}
