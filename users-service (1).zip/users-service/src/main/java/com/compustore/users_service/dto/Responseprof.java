package com.compustore.users_service.dto;

import com.compustore.users_service.model.Rol;

public record Responseprof(Long id, String username, Rol role) {}

