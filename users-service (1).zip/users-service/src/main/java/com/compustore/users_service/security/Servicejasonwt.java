package com.compustore.users_service.security;

import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Date;

import com.compustore.users_service.model.Rol;
import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class Servicejasonwt {
  @Value("${jwt.secret}") private String secret;
  @Value("${jwt.expiration-minutes}") private long expiration;

  public String generate(String username, Rol role, String name, String email, String phone, String address, String city, String state, String zip, String country, String avatar, String cover) {
    Instant now = Instant.now();
    return Jwts.builder()
      .setSubject(username)
      .claim("role", role.name())
      .claim("name", name)
      .claim("email", email)
      .claim("phone", phone)
      .claim("address", address)
      .claim("city", city)
      .claim("state", state)
      .claim("zip", zip)
      .claim("country", country)
      .claim("avatar", avatar)
      .claim("cover", cover)
      .setIssuedAt(Date.from(now))
      .setExpiration(Date.from(now.plus(expiration, ChronoUnit.MINUTES)))
      .signWith(Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8)), SignatureAlgorithm.HS256)
      .compact();
  }

  public Jws<Claims> parse(String token) {
    return Jwts.parserBuilder()
      .setSigningKey(Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8)))
      .build()
      .parseClaimsJws(token);
  }

  public String generate(String username, Rol role, String name, String email, String phone, String address, String city, String state, String zip, String country, String avatar, String cover) {
    Instant now = Instant.now();
    return Jwts.builder()
      .setSubject(username)
      .claim("role", role.name())
      .claim("name", name)
      .claim("email", email)
      .claim("phone", phone)
      .claim("address", address)
      .claim("city", city)
      .claim("state", state)
      .claim("zip", zip)
      .claim("country", country)
      .claim("avatar", avatar)
      .claim("cover", cover)
      .setIssuedAt(Date.from(now))
      .setExpiration(Date.from(now.plus(expiration, ChronoUnit.MINUTES)))
      .signWith(Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8)), SignatureAlgorithm.HS256)
      .compact();
  }
}
