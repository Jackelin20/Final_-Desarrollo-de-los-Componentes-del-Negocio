package com.compustore.users_service.api;

import com.compustore.users_service.dto.Responseauth;
import com.compustore.users_service.dto.Requestlog;
import com.compustore.users_service.dto.Responseprof;
import com.compustore.users_service.dto.Requestregi;
import com.compustore.users_service.model.Rol;
import com.compustore.users_service.model.Entityuser;
import com.compustore.users_service.security.Servicejasonwt;
import com.compustore.users_service.service.Serviceuser;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.swagger.v3.oas.annotations.security.SecurityRequirement; 
import jakarta.annotation.security.PermitAll;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class Controllerauth {
  private final Serviceuser userService;
  private final Servicejasonwt jwt;

  @PermitAll
  @PostMapping("/register")
  public ResponseEntity<Void> register(@RequestBody Requestregi req){
    if (req.role() == null) {
      req = new Requestregi(req.username(), req.password(), Rol.CLIENT); 
    }
    userService.register(req);
    return ResponseEntity.status(HttpStatus.CREATED).build();
  }

  @PermitAll
  @PostMapping({"/login", "/authenticate"})
  public Responseauth login(@RequestBody Requestlog req){
    Entityuser u = userService.authenticate(req);
    return new Responseauth(jwt.generate(u.getUsername(), u.getRole()));
  }

  @GetMapping("/profile")
  @SecurityRequirement(name = "bearerAuth") 
  public Responseprof profile(HttpServletRequest request) {
    String auth = request.getHeader(HttpHeaders.AUTHORIZATION);
    if (auth == null || !auth.startsWith("Bearer ")) {
      throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Falta Auth");
    }
    String token = auth.substring(7);
    Jws<Claims> claims = jwt.parse(token);
    String username = claims.getBody().getSubject();
    Entityuser u = userService.getByUsername(username).orElseThrow();
    return new Responseprof(u.getId(), u.getUsername(), u.getRole());
  }

  @GetMapping("/profile/{username}")
  @SecurityRequirement(name = "bearerAuth") 
  public Responseprof profile(@PathVariable String username) {
    Entityuser u = userService.getByUsername(username).orElseThrow();
    return new Responseprof(u.getId(), u.getUsername(), u.getRole());
  }


}
