package com.compustore.users_service.service;

import com.compustore.users_service.dto.Requestlog;
import com.compustore.users_service.dto.Requestregi;
import com.compustore.users_service.model.Entityuser;
import com.compustore.users_service.repo.Repositoryuser;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class Serviceuser {
  private final Repositoryuser repo;
  private final PasswordEncoder encoder;

  public void register(Requestregi req) {
    if (repo.findByUsername(req.username()).isPresent()) {
      // 409 Conflict si el usuario ya existe
      throw new ResponseStatusException(HttpStatus.CONFLICT, "Usuario ya existe");
    }
    var u = new Entityuser();
    u.setUsername(req.username());
    u.setPassword(encoder.encode(req.password()));
    u.setRole(req.role());
    repo.save(u);
  }

  public Entityuser authenticate(Requestlog req) {
    var u = repo.findByUsername(req.username())
        .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Credenciales inválidas"));
    if (!encoder.matches(req.password(), u.getPassword()))
        throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Credenciales inválidas");
    return u;
  }

  public Optional<Entityuser> getByUsername(String username) {
    return repo.findByUsername(username);
  }

  public Optional<Entityuser> getById(Long id) {
    return repo.findById(id);
  }

}
