package com.compustore.users_service.repo;

import com.compustore.users_service.model.Entityuser;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Repositoryuser extends JpaRepository<Entityuser, Long> {
  Optional<Entityuser> findByUsername(String username);
  Optional<Entityuser> findById(Long id);
  Optional<Entityuser> findByEmail(String email);
  Optional<Entityuser> findByPhone(String phone);
  Optional<Entityuser> findByAddress(String address);
  Optional<Entityuser> findByCity(String city);
  Optional<Entityuser> findByState(String state);
  Optional<Entityuser> findByZip(String zip);
  Optional<Entityuser> findByCountry(String country);
  Optional<Entityuser> findByAvatar(String avatar);
  Optional<Entityuser> findByCover(String cover);
}
