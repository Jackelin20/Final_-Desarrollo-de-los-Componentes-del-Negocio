package com.compustore.users_service.dto;

public record Responseauth(String token) {}
