package com.compustore.users_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.compustore.users_service.security.Servicejasonwt;

@SpringBootApplication
public class Appuserservi {

	public static void main(String[] args) {
		SpringApplication.run(Appuserservi.class, args);
	}

	@Bean
	PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	@Bean
	Servicejasonwt servicejasonwt() {
		return new Servicejasonwt();
	}

}
