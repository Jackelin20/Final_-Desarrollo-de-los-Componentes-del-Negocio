package com.compustore.users_service.dto;

import com.compustore.users_service.model.Rol;

public record Requestregi(String username, String password, Rol role) {}

