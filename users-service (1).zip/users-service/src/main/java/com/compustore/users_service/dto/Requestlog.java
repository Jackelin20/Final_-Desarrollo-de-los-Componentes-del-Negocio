package com.compustore.users_service.dto;

public record Requestlog(String username, String password) {}



