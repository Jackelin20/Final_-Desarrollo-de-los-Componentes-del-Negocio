package com.compustore.users_service.model;

public enum Rol { ADMIN, CLIENT }



