package com.compustore.users_service.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "users")
@Getter @Setter
public class Entityuser {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(unique = true, nullable = false)
  private String username;

  @Column(nullable = false)
  private String password; // guardada con BCrypt

  @Enumerated(EnumType.STRING)
  @Column(nullable = false)
  private Rol role;

  @Column(nullable = false)
  private String name;

  @Column(nullable = false)
  private String email;

  @Column(nullable = false)
  private String phone;

  @Column(nullable = false)
  private String address;

  @Column(nullable = false)
  private String city;

  @Column(nullable = false)
  private String state;

  @Column(nullable = false)
  private String zip;

  @Column(nullable = false)
  private String country;

  @Column(nullable = false)
  private String avatar;

  @Column(nullable = false)
  private String cover;
}
