# Products Service (Spring Boot 3)

Microservicio de **gestión de productos** protegido por **JWT** emitido por `users-service`.

## 🚀 Tech
- Java 17, Spring Boot 3.5.x
- Spring Web, Spring Security (filtro JWT), Spring Data JPA, Validation
- MySQL 8
- JJWT (validación HS256)
- Swagger/OpenAPI: springdoc-openapi

## ⚙️ Requisitos
- JDK 17
- Maven 3.9+
- MySQL en local (o remoto)
- **El mismo `JWT_SECRET`** que uses en `users-service`

## 🗃️ Base de datos (MySQL)
```sql
CREATE DATABASE products_db;
GRANT ALL PRIVILEGES ON products_db.* TO 'app'@'%';
FLUSH PRIVILEGES;
```

> JPA crea la tabla `products` automáticamente (id autoincremental, name, description, price, stock).

## 🔐 Variables de entorno
Debe coincidir con el secreto del `users-service`.

**Windows (PowerShell):**
```powershell
setx JWT_SECRET "pon-aqui-el-mismo-secreto-que-en-users-service"
```

**Linux/macOS (bash):**
```bash
echo 'export JWT_SECRET=pon-aqui-el-mismo-secreto-que-en-users-service' >> ~/.bashrc
source ~/.bashrc
```

## 🔧 Configuración (`src/main/resources/application.properties`)
```properties
server.port=8082

spring.datasource.url=jdbc:mysql://localhost:3306/products_db?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true
spring.datasource.username=app
spring.datasource.password=app

spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true

jwt.secret=${JWT_SECRET:change-me-in-dev}
```

## ▶️ Ejecutar
```bash
mvn spring-boot:run
# Swagger: http://localhost:8082/swagger-ui/index.html
```

En Swagger, usa el botón **Authorize** y pega **solo** el token (sin escribir “Bearer”).

## 👤 Roles y permisos
- **CLIENT** y **ADMIN**: pueden **ver** productos (`GET`).
- **ADMIN**: puede **crear/editar/eliminar** (`POST/PUT/DELETE`).

## 📡 Endpoints
- `GET /api/products` → Lista (CLIENT/ADMIN)
- `GET /api/products/{id}` → Detalle (CLIENT/ADMIN)
- `POST /api/products` → Crear (ADMIN)
  ```json
  { "name": "Laptop Pro", "description": "16GB/512GB", "price": 1999.99, "stock": 5 }
  ```
  *(No envíes `id` en el POST; lo genera la BD)*
- `PUT /api/products/{id}` → Actualizar (ADMIN)
- `DELETE /api/products/{id}` → Borrar (ADMIN)

## 🧪 Pruebas rápidas (cURL)
1) Obtén el token en `users-service`:
```bash
curl -s -X POST "http://localhost:8081/api/users/login" \
 -H "Content-Type: application/json" \
 -d '{"username":"admin","password":"1234"}'
```

2) Usa el token en `products-service`:
```bash
# crear (ADMIN)
curl -s -X POST "http://localhost:8082/api/products" \
 -H "Content-Type: application/json" \
 -H "Authorization: Bearer <TOKEN>" \
 -d '{"name":"Laptop Pro","description":"16GB/512GB","price":1999.99,"stock":5}'

# listar (CLIENT/ADMIN)
curl -s -H "Authorization: Bearer <TOKEN>" "http://localhost:8082/api/products"
```

## 🔒 Seguridad (cómo funciona)
- Un **filtro JWT** valida la firma HS256 con `jwt.secret` y extrae `sub` (usuario) y `role`.
- Spring Security aplica reglas por método HTTP:
  - `GET` → `hasAnyRole('CLIENT','ADMIN')`
  - `POST/PUT/DELETE` → `hasRole('ADMIN')`

## 🧰 Problemas comunes
- `401 Unauthorized` → token inválido/expirado o falta header `Authorization`.
- `403 Forbidden` → usas token de **CLIENT** en una operación de **ADMIN**.
- `500` al crear → no envíes `id` en el `POST` o revisar esquema en MySQL.
