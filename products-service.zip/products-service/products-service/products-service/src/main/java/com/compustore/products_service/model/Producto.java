package com.compustore.products_service.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.Getter; import lombok.Setter;
import java.math.BigDecimal;

@Entity @Table(name = "products")
@Getter @Setter
public class Producto {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @NotBlank
  @Column(nullable = false)
  private String name;

  private String description;

  @NotNull @DecimalMin("0.0")
  @Column(nullable = false)
  private BigDecimal price;

  @Min(0)
  private Integer stock;

  @PrePersist
  private void prePersist() {
    this.stock = this.stock != null ? this.stock : 0;
  }

  @PreUpdate
  private void preUpdate() {
    this.stock = this.stock != null ? this.stock : 0;
  }

  @PreRemove
  private void preRemove() {
    this.stock = this.stock != null ? this.stock : 0;
  }

  @PreRemove
  private void preRemove() {
    this.stock = this.stock != null ? this.stock : 0;
  }
}
