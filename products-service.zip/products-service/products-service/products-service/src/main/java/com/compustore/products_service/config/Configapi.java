package com.compustore.products_service.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.security.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Configapi {
  @Bean
  public OpenAPI api() {
    final String scheme = "bearerAuth";
    return new OpenAPI()
      .info(new Info()
        .title("Products API")
        .description("Gestión de productos protegida con JWT emitido por users-service")
        .version("v1"))
      .addSecurityItem(new SecurityRequirement().addList(scheme))
      .components(new Components().addSecuritySchemes(scheme,
        new SecurityScheme().name(scheme).type(SecurityScheme.Type.HTTP)
          .scheme("bearer").bearerFormat("JWT")));
  }
}
