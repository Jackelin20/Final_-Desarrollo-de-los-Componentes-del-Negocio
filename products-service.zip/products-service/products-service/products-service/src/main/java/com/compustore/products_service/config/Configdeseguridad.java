package com.compustore.products_service.config;

import com.compustore.products_service.security.Filtroauthjwt;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableMethodSecurity
public class Configdeseguridad {

  private final Filtroauthjwt jwtFilter;
  public Configdeseguridad(Filtroauthjwt jwtFilter){ this.jwtFilter = jwtFilter; }

  @Bean
  SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
    return http
      .csrf(AbstractHttpConfigurer::disable)
      .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
      .authorizeHttpRequests(auth -> auth
        .requestMatchers("/v3/api-docs/**", "/swagger-ui/**", "/swagger-ui.html", "/error").permitAll()

        // GET: CLIENT o ADMIN
        .requestMatchers(org.springframework.http.HttpMethod.GET, "/api/products/**")
          .hasAnyRole("CLIENT","ADMIN")

        // POST/PUT/DELETE: solo ADMIN
        .requestMatchers(org.springframework.http.HttpMethod.POST,   "/api/products/**").hasRole("ADMIN")
        .requestMatchers(org.springframework.http.HttpMethod.PUT,    "/api/products/**").hasRole("ADMIN")
        .requestMatchers(org.springframework.http.HttpMethod.DELETE, "/api/products/**").hasRole("ADMIN")

        .anyRequest().authenticated()
      )
      .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class)
      .build();
  }

  @Bean
  public PasswordEncoder passwordEncoder() {
    return new BCryptPasswordEncoder();
  }

  @Bean
  public AuthenticationManager authenticationManager(AuthenticationConfiguration authConfig) throws Exception {
    return authConfig.getAuthenticationManager();
  }

  @Bean
  public Filtroauthjwt jwtAuthFilter() {
    return new Filtroauthjwt();
  }
}
