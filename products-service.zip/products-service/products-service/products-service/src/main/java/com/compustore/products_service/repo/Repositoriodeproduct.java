package com.compustore.products_service.repo;

import com.compustore.products_service.model.Producto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Repositoriodeproduct extends JpaRepository<Producto, Long> {}
