package com.compustore.products_service.api;

import com.compustore.products_service.model.Producto;
import com.compustore.products_service.repo.Repositoriodeproduct;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/products")
@RequiredArgsConstructor
public class Controladorproducto {

  private final Repositoriodeproduct repo;

  // 1) GET /api/products
  @GetMapping
  public List<Producto> all() { return repo.findAll(); }

  // 2) GET /api/products/{id}
  @GetMapping("/{id}")
  public ResponseEntity<Producto> one(@PathVariable Long id) {
    return repo.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
  }

  // 3) POST /api/products  (ADMIN)
  @PostMapping
  public ResponseEntity<Producto> create(@Valid @RequestBody Producto p) {
    return ResponseEntity.status(HttpStatus.CREATED).body(repo.save(p));
  }

  // 4) PUT /api/products/{id} (ADMIN)
  @PutMapping("/{id}")
  public ResponseEntity<Producto> update(@PathVariable Long id, @Valid @RequestBody Producto p) {
    return repo.findById(id).map(old -> {
      old.setName(p.getName());
      old.setDescription(p.getDescription());
      old.setPrice(p.getPrice());
      old.setStock(p.getStock());
      return ResponseEntity.ok(repo.save(old));
    }).orElse(ResponseEntity.notFound().build());
  }

  // 5) DELETE /api/products/{id} (ADMIN)
  @DeleteMapping("/{id}")
  public ResponseEntity<Void> delete(@PathVariable Long id) {
    if (!repo.existsById(id)) return ResponseEntity.notFound().build();
    repo.deleteById(id);
    return ResponseEntity.noContent().build();
  }

  // 6) GET /api/products/{id}/stock
  @GetMapping("/{id}/stock")
  public ResponseEntity<Integer> getStock(@PathVariable Long id) {
    return repo.findById(id).map(p -> ResponseEntity.ok(p.getStock()))
      .orElse(ResponseEntity.notFound().build());
  }

  // 7) PUT /api/products/{id}/stock (ADMIN)
  @PutMapping("/{id}/stock")
  public ResponseEntity<Producto> updateStock(@PathVariable Long id, @Valid @RequestBody Producto p) {
    return repo.findById(id).map(old -> {
      old.setStock(p.getStock());
      return ResponseEntity.ok(repo.save(old));
    }).orElse(ResponseEntity.notFound().build());
  }

  // 8) GET /api/products/{id}/price
  @GetMapping("/{id}/price")
  public ResponseEntity<Integer> getPrice(@PathVariable Long id) {
    return repo.findById(id).map(p -> ResponseEntity.ok(p.getPrice()))
      .orElse(ResponseEntity.notFound().build());
  }

  // 9) PUT /api/products/{id}/price (ADMIN)
  @PutMapping("/{id}/price")
  public ResponseEntity<Producto> updatePrice(@PathVariable Long id, @Valid @RequestBody Producto p) {
    return repo.findById(id).map(old -> {
      old.setPrice(p.getPrice());
      return ResponseEntity.ok(repo.save(old));
    }).orElse(ResponseEntity.notFound().build());
  }
}
